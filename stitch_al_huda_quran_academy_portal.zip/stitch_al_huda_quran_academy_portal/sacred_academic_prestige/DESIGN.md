---
name: Sacred Academic Prestige
colors:
  surface: '#f3fcf3'
  surface-dim: '#d3dcd4'
  surface-bright: '#f3fcf3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#edf6ee'
  surface-container: '#e7f0e8'
  surface-container-high: '#e2eae2'
  surface-container-highest: '#dce5dd'
  on-surface: '#151d19'
  on-surface-variant: '#3f4942'
  inverse-surface: '#2a322d'
  inverse-on-surface: '#eaf3eb'
  outline: '#6f7a71'
  outline-variant: '#bec9bf'
  surface-tint: '#006d44'
  primary: '#005f3b'
  on-primary: '#ffffff'
  primary-container: '#0f7a4e'
  on-primary-container: '#a7ffcb'
  inverse-primary: '#7cd9a5'
  secondary: '#755b00'
  on-secondary: '#ffffff'
  secondary-container: '#fed255'
  on-secondary-container: '#735a00'
  tertiary: '#1a5e3e'
  on-tertiary: '#ffffff'
  tertiary-container: '#367755'
  on-tertiary-container: '#b7fcd1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#98f6bf'
  primary-fixed-dim: '#7cd9a5'
  on-primary-fixed: '#002111'
  on-primary-fixed-variant: '#005232'
  secondary-fixed: '#ffe08e'
  secondary-fixed-dim: '#ecc246'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#584400'
  tertiary-fixed: '#aef2c7'
  tertiary-fixed-dim: '#92d5ac'
  on-tertiary-fixed: '#002111'
  on-tertiary-fixed-variant: '#075133'
  background: '#f3fcf3'
  on-background: '#151d19'
  surface-variant: '#dce5dd'
  mint-tint: '#E8F5EE'
  accent-gold: '#E5BA38'
  amber-cream: '#FDF8ED'
  canvas-cream: '#FAFAF7'
  surface-subtle: '#F4F6F3'
  border-gilded: '#E6D7A8'
  border-hairline: '#E2E8E4'
  trust-blue: '#1E5AA8'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 52px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  display-md:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.015em
  display-md-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

This design system establishes an authoritative, premier international e-learning standard for sacred Quranic and Arabic education. Combining the academic gravitas of elite digital institutions (such as Coursera, Cambridge Online, and MasterClass) with the timeless spiritual dignity of authentic Islamic scholarship, the interface inspires instant trust, safety, and reverence among Muslim diaspora families across the UK, USA, Canada, and Australia.

The aesthetic philosophy centers on **Refined Academic Minimalism with Classical Islamic Flourishes**. Clean ivory canvases, architectural column grids, and generous breathing room elevate sacred pedagogy beyond transient commercial ed-tech. Deep emerald greens anchor institutional rigor, warm royal golds symbolize enlightenment and honor (Ijazah), while precise, gossamer-thin geometric star arabesques (girih motifs at 4–6% opacity) provide sublime cultural grounding.

The user experience evokes absolute peace of mind: rigorous DBS safeguarding cues, verified Al-Azhar and Medina Ijazah accreditations, multi-currency clarity, and compassionate clarity for both young learners and busy professional parents.

## Colors

The palette balances the organic vitality of Islamic emerald hues with the refined luminescence of noble metallics and warm, non-glare parchment tones:

- **Primary (`#0F7A4E`) & Tertiary Deep Emerald (`#0A5334`)**: Serve as the institutional bedrock, utilized for key navigation, authoritative action triggers, active tab states, and primary credentials.
- **Secondary Gold (`#C9A227`) & Accent Gold (`#E5BA38`)**: Evoke illumination, academic honor, and excellence. Reserved for key visual accents, Ijazah badge rings, rating stars, premium tiers, and active highlights.
- **Neutral Charcoal (`#1C241F`)**: An ink-black tinted with deep forest green to avoid sterile grayscale and maintain harmony with emerald typography.
- **Surfaces & Canvases (`#FAFAF7`, `#FDF8ED`, `#E8F5EE`)**: Ivory and warm parchment replace stark synthetic white on large expanses, preventing optical fatigue during intense recitation and study sessions while referencing classical vellum manuscripts.
- **Trust Accents (`#1E5AA8`)**: Deployed exclusively for verified Western compliance items: UK DBS Child Safeguarding shields, PCI/SSL banking guarantees, and ISO quality badges.

## Typography

The typographic hierarchy pairs classical Latin-Serif editorial grandeur with modern humanist sans-serif efficiency:

- **Headlines & Display (Playfair Display)**: Infuses editorial scholarship and classic academy prestige. Applied to hero proclamations, course tracks, degree program titles, and formal testimonials.
- **Body & Functional UI (Plus Jakarta Sans)**: Ensures maximum legibility across schedules, live classroom portals, multi-tier pricing plans, and curriculum breakdown sheets. Its geometric balance provides frictionless reading for international students and parents.
- **Quranic & Arabic Inscriptions**: When inline sacred verses or Tajweed terminology appear, they are styled with specialized high-calligraphy Arabic font families (`Amiri` or `Scheherazade New`) set 1.25x larger than the surrounding Latin text to preserve diacritical (Tashkeel) clarity and respect traditional proportion.

## Layout & Spacing

The layout is built upon an architectural 12-column grid system (desktop) collapsing gracefully into 8 columns (tablet) and 4 columns (mobile):

- **Desktop (1200px - 1440px max-width)**: Generous 32px gutters and spacious outer canvas margins ensure content breathes with academic nobility.
- **Vertical Rhythm**: Large section gaps (`space-2xl` to `space-3xl`) demarcate high-value thematic segments (e.g., Faculty Credentials, Curriculum Roadmaps, Safeguarding Protocol, Pricing).
- **Asymmetrical Card Formations**: Curriculum modules feature structured 2/3 and 1/3 column layouts, allowing course tracks to sit alongside live teacher status and tutor booking widgets.
- **Subtle Cultural Framing**: Sections occasionally terminate in hairline dual-tone rules (Emerald fading into Gold) or ultra-subtle arches inspired by classical mihrab geometry.

## Elevation & Depth

Visual hierarchy uses **Tonal Layering combined with Ambient Warm Shadows**:

- **Layering Philosophy**: Flat stark white surfaces are avoided. Elevation begins from the base canvas (`#FAFAF7`), rising through elevated cards (`#FFFFFF`) with a micro-stroke hairline (`#E2E8E4`).
- **Shadow Tinting**: Shadows never utilize dead black or cool gray. Instead, they are cast with warm forest and gold-tinted umbers: `0 8px 30px -6px rgba(10, 83, 52, 0.08), 0 4px 12px -2px rgba(201, 162, 39, 0.04)`.
- **Accreditation Glass Tiers**: Safeguarding banners, verified Ijazah seals, and tutor badges utilize a frosted dual-layer backing (`rgba(255, 255, 255, 0.85)` with `backdrop-filter: blur(12px)` and a soft 1px border `rgba(201, 162, 39, 0.2)`).
- **Interactive Depth**: Elevated elements subtly translate -2px on hover, deepening the warm ambient shadow to convey tangible, tactile presence.

## Shapes

The geometric framework balances contemporary software clarity with the welcoming warmth suited to family education:

- **Radius Scale (Level 2 - Rounded)**: Base components (buttons, input fields, badges) employ `0.5rem` (8px). Medium surface elements and cards adopt `rounded-lg` (16px / `1rem`), while hero feature banners and modal dialogs extend to `rounded-xl` (24px / `1.5rem`).
- **Curved Architectural Cutouts**: Feature cards and tutor spotlight frames frequently feature an inverted corner arch or subtle Islamic apex arch at the top edge, celebrating historical Madrasah architecture in a sharp, modern SVG vector execution.
- **Pill Accents**: Safeguarding chips, currency selectors, and trial lesson badges utilize pill geometry (`9999px`) to immediately separate metadata from foundational structural cards.

## Components

### Buttons & CTAs
- **Primary Institutional CTA**: Solid deep emerald (`#0F7A4E`) with white text and `font-weight: 600`. Hover transforms to `#0A5334` with an inner radiant glow of gold (`rgba(201, 162, 39, 0.2)`).
- **Secondary Academic CTA**: Warm royal gold outline (`#C9A227`, 1.5px) over ivory background, transitioning to an amber cream fill (`#FDF8ED`) on hover.
- **Trial & Diagnostic CTA**: Gradient accent button running subtly from `#C9A227` to `#E5BA38` with dark charcoal text (`#1C241F`) for maximum visual pop on registration funnels.

### Cards & Module Containers
- **Course & Faculty Cards**: Pristine white canvas with 1px border (`#E2E8E4`), rounded at 16px. Top right corner houses verified qualification badges (e.g., "Al-Azhar Certified" or "Female Tutor Available").
- **Tutor Profile Card**: Circular avatar with an emerald-and-gold dual-ring border, accompanied by native flag tags (UK, US, EG), verified audio pronunciation sample player, and student rating stars in `#E5BA38`.

### Badges, Trust Chips & Safeguarding
- **DBS & Child Safeguarding Shield**: `#E8F5EE` background, `#0A5334` bold typography, accompanied by a verified check icon and a trust-blue lock glyph.
- **Currency Switcher**: Minimalist pill selector allowing effortless switching between GBP (£), USD ($), CAD ($), and EUR (€), updating pricing tiers and exchange-rate transparency dynamically.
- **Guarantee Seals**: Circular embossed badge design with golden radial sunburst rims indicating "100% Satisfaction or Money-Back Guarantee" and "1-on-1 Free Evaluation".

### Input Fields & Selectors
- **Form Controls**: Crisp 48px height, rounded at 8px, `#FFFFFF` interior with `#E2E8E4` baseline border. 
- **Focus States**: 2px ring in primary emerald (`#0F7A4E`) with a soft 4px ambient haze of gold (`rgba(201, 162, 39, 0.25)`). Labels use `Plus Jakarta Sans` Medium with optional Arabic translation tooltips.

### Classroom Schedule & Live Indicators
- **Real-time Availability Slot**: Micro-pill calendar chip featuring an animated pulse ring in `#0F7A4E` denoting "Available Today" for cross-timezone scheduling convenience.